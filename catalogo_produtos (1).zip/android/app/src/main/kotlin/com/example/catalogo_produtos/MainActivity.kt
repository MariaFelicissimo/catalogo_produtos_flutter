package com.example.catalogo_produtos

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
