import '../models/product.dart';

final List<Product> sampleProducts = [
  Product(
    name: 'Tênis Esportivo',
    imageUrl: 'lib/assets/images/Screenshot_10.png',
    description: 'Tênis confortável para corrida.',
    price: 199.99,
  ),
  Product(
    name: 'Camisa Casual',
    imageUrl: 'lib/assets/images/Screenshot_11.png',
    description: 'Camisa para uso diário.',
    price: 89.90,
  ),
  Product(
    name: 'Palmilha Gel Laranja Etiqueta Branca',
    imageUrl: 'lib/assets/images/IMG_0790.jpg',
    description:
        'Palmilha Conforto Para tenis e coturnos. Disponivel do 35 ao 46',
    price: 10.00,
  ),
  Product(
    name: 'Mocassim Feminino 004 azul',
    imageUrl: 'lib/assets/images/Foto3 (1).jpg',
    description:
        'Mocassim Feminino em couro legitimo conforto. Disponivel do 33 ao 40',
    price: 64.90,
  ),
  Product(
    name: 'Mocassim Feminino 010 Branco',
    imageUrl: 'lib/assets/images/IMG_1906.JPG',
    description:
        'Mocassim Feminino Para enfermeiras em couro legitimo conforto. Disponivel do 33 ao 40',
    price: 64.90,
  ),
  Product(
    name: 'Coturno Caterpillar 2064 Cafe',
    imageUrl: 'lib/assets/images/2064 Intruder - Nobuck Café (1).jpg',
    description:
        'Coturno em couro legitimo Caterpillar com palmilha conforto. Disponivel do 35 ao 46',
    price: 135.90,
  ),
  Product(
    name: 'Coturno Timberland Strength Preto',
    imageUrl: 'lib/assets/images/Strength.jpg',
    description:
        'Coturno em couro legitimo Timberland com palmilha conforto. Disponivel do 37 ao 46, valor minimo de venda : 250,00',
    price: 139.00,
  ),
];
